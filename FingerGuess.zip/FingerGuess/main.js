    var r,scores=0,grade=4,lastHumanChoice;
    var lastWinner="noone",lastComputerChoice="rock";
	function rock(){		
		document.getElementById("myChoice").innerHTML="<img src='image/rock.png' />"//这里的单引号也可以是转义代替 → \" 		
		judge("rock");
		lastHumanChoice="rock";
	}
	function scissors(){		
		document.getElementById("myChoice").innerHTML="<img src='image/scissors.png' />"		
        judge("scissors");
        lastHumanChoice="scissors";
	}
	function paper(){
		document.getElementById("myChoice").innerHTML="<img src='image/paper.png' />"
		judge("paper");
		lastHumanChoice="paper";
	}
	function go(){				
		//alert(r);
		//document.body.innerHTML=r;		
	}
	function judge(myChoice){
		r=Math.random()*3;
		var computerResult;
		if (grade==1) {
			computerResult=onlyRock();
		}
		else if(grade==2){
			computerResult=leaarnFromHuman();
		}
		else if (grade==3) {
			computerResult=winnerAgain();
			lastComputerChoice=computerResult;
		}
		else if (grade==4) {
			computerResult=loseChange();
			lastComputerChoice=computerResult;
		}
		else{
			computerResult=computerChoice(); 
		}
		
		if(myChoice=="rock"){
			if(computerResult=="rock"){
			lastWinner="noone";
		} 
		else if (computerResult=="scissors") {
			lastWinner="human";
			scores++;
		}
		else{
			lastWinner="computer";
			scores--;
		}
		}
		else if (myChoice=="scissors") {
			if(computerResult=="rock"){
				lastWinner="computer";
			scores--;
		} 
		else if (computerResult=="scissors") {
			lastWinner="noone";
		}
		else{
			lastWinner="human";
			scores++;
		}
		}
		else{
			if(computerResult=="rock"){
				lastWinner="human";
			scores++;
		} 
		else if (computerResult=="scissors") {
			lastWinner="computer";
			scores--;
		}
		else{
			lastWinner="noone";;
		}
		}
		if (scores>=5) {
			scores=0;
			grade++;
		}
		document.getElementById("result").innerHTML="第"+grade+"关,您的积分为："+scores;
		if(grade>=10){
 			document.getElementById("result").innerHTML="通关";
		}
	}
	function computerChoice(){
		if (r<1) {
			document.getElementById("computerChoice").innerHTML="<img src='image/rock.png'>";
			return "rock";
		}
		else if (r<2) {
			document.getElementById("computerChoice").innerHTML="<img src='image/scissors.png'>";
			return "scissors";
		}
		else{
			document.getElementById("computerChoice").innerHTML="<img src='image/paper.png'>";
			return "paper";
		}
	}
	function onlyRock(){
		document.getElementById("computerName").innerHTML="电脑大锤哥";
		document.getElementById("computerChoice").innerHTML="<img src='image/rock.png'>";
		return "rock";
	}
	function leaarnFromHuman(){
		document.getElementById("computerName").innerHTML="模仿帝";
		document.getElementById("computerChoice").innerHTML="<img src='image/"+lastHumanChoice+".png'>";
		return lastHumanChoice;
	}
	function winnerAgain(){
		document.getElementById("computerName").innerHTML="赢了还出";
		if (lastWinner=="computer") {
			document.getElementById("computerChoice").innerHTML="<img src='image/"+lastComputerChoice+".png'>";
			return lastComputerChoice;
		}
		var temp = computerChoice();
		document.getElementById("computerChoice").innerHTML="<img src='image/"+temp+".png'>";
		return temp;
	}
	function loseChange(){
		document.getElementById("computerName").innerHTML="输了就换";
		if (lastWinner=="human") {
			var temp= getResultExclude(lastComputerChoice);;
			document.getElementById("computerChoice").innerHTML="<img src='image/"+temp+".png'>";
			return temp;
		}
		temp = computerChoice();
		document.getElementById("computerChoice").innerHTML="<img src='image/"+temp+".png'>";
		return temp;
	}
	function getResultExclude(exclusion){
		var temp=computerChoice();
		if(temp==exclusion){
			return getResultExclude(exclusion);
		}
		else{
			return temp;
		}
	}